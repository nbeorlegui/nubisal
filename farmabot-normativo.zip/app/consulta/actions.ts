"use server";

import { requireUser } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { normalizeQuery } from "@/lib/pdf-processor";
import { revalidatePath } from "next/cache";

type SearchSource = {
  documentTitle: string;
  healthInsuranceName: string;
  pageNumber: number | null;
  excerpt: string;
  score: number;
};

export type ChatSearchResponse = {
  answer: string;
  sources: SearchSource[];
};

type ChunkForSearch = {
  id: string;
  documentId: string;
  pageId: string | null;
  healthInsuranceId: string;
  content: string;
  normalizedContent: string;
  keywords: string[];
  scoreBase: number;
  document: {
    title: string;
  };
  page: {
    pageNumber: number;
  } | null;
  healthInsurance: {
    name: string;
    code: string | null;
  };
};

type ScoredChunk = ChunkForSearch & {
  score: number;
  bestExcerpt: string;
  excerptScore: number;
  confidence: "high" | "medium" | "low";
};

const STOP_WORDS = new Set([
  "de",
  "del",
  "la",
  "las",
  "el",
  "los",
  "un",
  "una",
  "unos",
  "unas",
  "y",
  "o",
  "a",
  "en",
  "por",
  "para",
  "con",
  "sin",
  "que",
  "se",
  "al",
  "es",
  "son",
  "como",
  "cual",
  "cuál",
  "cuales",
  "cuáles",
  "cuando",
  "cuándo",
  "cuanto",
  "cuánto",
  "cuantos",
  "cuántos",
  "necesito",
  "quiero",
  "saber",
  "consulta",
  "consultar",
  "obra",
  "social",
  "obras",
  "sociales",
  "normativa",
  "normativas",
  "documento",
  "documentos",
  "farmacia",
  "farmacias",
]);

const SYNONYM_GROUPS = [
  ["validez", "vigencia", "vencimiento", "vence", "vencer", "plazo", "duracion", "dura"],
  ["receta", "recetario", "prescripcion", "prescripto", "prescripta", "indicacion", "orden"],
  ["autorizacion", "autorizar", "auditoria", "validacion", "aprobacion"],
  ["requisito", "requisitos", "documentacion", "documentos", "presentar", "solicita", "pide", "requiere"],
  ["cobertura", "cubre", "cubierto", "cubiertos", "descuento", "porcentaje", "cargo"],
  ["medicamento", "medicamentos", "droga", "drogas", "farmaco", "farmacos", "producto", "productos"],
  ["afiliado", "beneficiario", "paciente", "socio"],
  ["cantidad", "cantidades", "unidades", "unidad", "envases", "envase", "tope", "limite"],
];

function stemWord(word: string) {
  let value = normalizeQuery(word);

  if (value.length > 8 && value.endsWith("aciones")) {
    value = value.slice(0, -7) + "acion";
  } else if (value.length > 7 && value.endsWith("cion")) {
    value = value.slice(0, -4);
  } else if (value.length > 6 && value.endsWith("es")) {
    value = value.slice(0, -2);
  } else if (value.length > 5 && value.endsWith("s")) {
    value = value.slice(0, -1);
  }

  return value;
}

function unique(values: string[]) {
  return Array.from(new Set(values.filter(Boolean)));
}

function getRawWords(value: string) {
  return normalizeQuery(value)
    .split(" ")
    .map((word) => word.trim())
    .filter(Boolean);
}

function removeHealthInsuranceTerms(words: string[], healthInsurance?: { name: string; code?: string | null } | null) {
  if (!healthInsurance) return words;

  const removeSet = new Set([
    ...getRawWords(healthInsurance.name),
    ...getRawWords(healthInsurance.code ?? ""),
  ]);

  return words.filter((word) => !removeSet.has(word));
}

function expandTerms(words: string[]) {
  const baseWords = words
    .map((word) => normalizeQuery(word))
    .filter((word) => word.length >= 3 && !STOP_WORDS.has(word));

  const expanded: string[] = [];

  for (const word of baseWords) {
    expanded.push(word, stemWord(word));

    for (const group of SYNONYM_GROUPS) {
      const normalizedGroup = group.map(normalizeQuery);

      if (normalizedGroup.includes(word) || normalizedGroup.includes(stemWord(word))) {
        expanded.push(...normalizedGroup);
      }
    }
  }

  return unique(expanded).filter((word) => word.length >= 3);
}

function hasTokenLike(content: string, term: string) {
  if (!term) return false;

  if (content.includes(term)) return true;

  const stem = stemWord(term);
  if (stem.length >= 4 && content.includes(stem)) return true;

  return false;
}

function getMatchedTerms(content: string, terms: string[]) {
  return terms.filter((term) => hasTokenLike(content, term));
}

function getLineBlocks(content: string) {
  const cleaned = content
    .replace(/\r/g, "")
    .replace(/[ \t]+/g, " ")
    .replace(/\n{3,}/g, "\n\n")
    .trim();

  const rawBlocks = cleaned
    .split(/\n{2,}|(?<=\.)\s+(?=[A-ZÁÉÍÓÚÑ])/g)
    .map((block) => block.trim())
    .filter(Boolean);

  if (rawBlocks.length <= 1) {
    const sentences = cleaned
      .split(/(?<=[.!?])\s+|(?=\b[A-ZÁÉÍÓÚÑ][A-ZÁÉÍÓÚÑ ]{4,}:?\b)/g)
      .map((block) => block.trim())
      .filter(Boolean);

    return sentences.length > 0 ? sentences : [cleaned];
  }

  return rawBlocks;
}

function isHeadingLike(text: string) {
  const clean = text.trim();
  if (clean.length < 4 || clean.length > 140) return false;

  const upperLetters = clean.replace(/[^A-ZÁÉÍÓÚÑ]/g, "").length;
  const lowerLetters = clean.replace(/[^a-záéíóúñ]/g, "").length;
  const ratio = upperLetters / Math.max(upperLetters + lowerLetters, 1);

  return ratio > 0.65 || clean.endsWith(":");
}

function questionExpectsConcreteValue(question: string) {
  const normalized = normalizeQuery(question);

  return /\b(cuanto|cuantos|cuanta|cuantas|dias|dia|mes|meses|ano|años|validez|vigencia|vencimiento|vence|plazo|porcentaje|descuento|cobertura|cantidad|tope|limite)\b/.test(
    normalized
  );
}

function hasConcreteValue(text: string) {
  return /(\b\d+\b|\buno\b|\bdos\b|\btres\b|\bcuatro\b|\bcinco\b|\bdiez\b|\bquince\b|\btreinta\b|\bcuarenta\b|\bcincuenta\b|\bsesenta\b|\bnoventa\b|\b(cien|100)\b|%|por ciento|dias?|mes(?:es)?|años?|horas?|unidades?|envases?)/i.test(
    text
  );
}

function scoreTextAgainstQuestion({
  text,
  questionTerms,
  exactQuestion,
  expectsConcreteValue,
}: {
  text: string;
  questionTerms: string[];
  exactQuestion: string;
  expectsConcreteValue: boolean;
}) {
  const normalized = normalizeQuery(text);
  const matchedTerms = getMatchedTerms(normalized, questionTerms);
  let score = 0;

  score += matchedTerms.length * 12;

  for (const term of matchedTerms) {
    if (term.length >= 7) score += 4;
  }

  if (exactQuestion && normalized.includes(exactQuestion)) {
    score += 80;
  }

  if (isHeadingLike(text) && matchedTerms.length > 0) {
    score += 18;
  }

  if (expectsConcreteValue && hasConcreteValue(text)) {
    score += 22;
  }

  if (matchedTerms.length >= 2) {
    const positions = matchedTerms
      .map((term) => normalized.indexOf(term))
      .filter((position) => position >= 0)
      .sort((a, b) => a - b);

    if (positions.length >= 2) {
      const span = positions[positions.length - 1] - positions[0];
      if (span <= 80) score += 35;
      else if (span <= 180) score += 20;
      else if (span <= 360) score += 8;
    }
  }

  return {
    score,
    matchedTerms,
  };
}

function extractBestExcerpt(content: string, questionTerms: string[], exactQuestion: string, question: string) {
  const blocks = getLineBlocks(content);
  const expectsConcreteValue = questionExpectsConcreteValue(question);

  const candidates: { text: string; score: number; matchedTerms: string[] }[] = [];

  for (let index = 0; index < blocks.length; index++) {
    const current = blocks[index];
    const previous = index > 0 ? blocks[index - 1] : "";
    const next = index < blocks.length - 1 ? blocks[index + 1] : "";

    const windows = [current];

    if (previous && current.length < 500) {
      windows.push(`${previous}\n${current}`.trim());
    }

    if (next && current.length < 700) {
      windows.push(`${current}\n${next}`.trim());
    }

    if (previous && next && current.length < 420) {
      windows.push(`${previous}\n${current}\n${next}`.trim());
    }

    for (const text of windows) {
      const result = scoreTextAgainstQuestion({
        text,
        questionTerms,
        exactQuestion,
        expectsConcreteValue,
      });

      candidates.push({
        text,
        score: result.score,
        matchedTerms: result.matchedTerms,
      });
    }
  }

  const best = candidates.sort((a, b) => b.score - a.score)[0];

  if (!best || best.score <= 0) {
    return {
      excerpt: content.slice(0, 700).trim(),
      score: 0,
    };
  }

  let excerpt = best.text.trim();

  if (excerpt.length > 900) {
    const normalized = normalizeQuery(excerpt);
    const firstMatch = questionTerms
      .map((term) => normalized.indexOf(term))
      .filter((index) => index >= 0)
      .sort((a, b) => a - b)[0];

    if (typeof firstMatch === "number") {
      const start = Math.max(firstMatch - 180, 0);
      excerpt = excerpt.slice(start, start + 900).trim();
    } else {
      excerpt = excerpt.slice(0, 900).trim();
    }
  }

  return {
    excerpt,
    score: best.score,
  };
}

function scoreChunk({
  chunk,
  questionTerms,
  exactQuestion,
  question,
}: {
  chunk: ChunkForSearch;
  questionTerms: string[];
  exactQuestion: string;
  question: string;
}) {
  const normalized = chunk.normalizedContent;
  const expectsConcreteValue = questionExpectsConcreteValue(question);
  const matchedTerms = getMatchedTerms(normalized, questionTerms);
  const keywordMatches = chunk.keywords.filter((keyword) =>
    questionTerms.some((term) => keyword.includes(term) || term.includes(keyword))
  );

  let score = 0;
  score += matchedTerms.length * 10;
  score += keywordMatches.length * 8;
  score += Math.min(chunk.scoreBase || 0, 10);

  if (exactQuestion && normalized.includes(exactQuestion)) {
    score += 90;
  }

  if (expectsConcreteValue && hasConcreteValue(chunk.content)) {
    score += 22;
  }

  if (matchedTerms.length >= 2) {
    const positions = matchedTerms
      .map((term) => normalized.indexOf(term))
      .filter((position) => position >= 0)
      .sort((a, b) => a - b);

    if (positions.length >= 2) {
      const span = positions[positions.length - 1] - positions[0];
      if (span <= 90) score += 50;
      else if (span <= 220) score += 30;
      else if (span <= 500) score += 12;
    }
  }

  const titleScore = scoreTextAgainstQuestion({
    text: chunk.content.slice(0, 180),
    questionTerms,
    exactQuestion,
    expectsConcreteValue,
  }).score;

  score += Math.min(titleScore, 55);

  const bestExcerpt = extractBestExcerpt(chunk.content, questionTerms, exactQuestion, question);
  score += Math.min(bestExcerpt.score, 75);

  let confidence: ScoredChunk["confidence"] = "low";
  if (score >= 95 && matchedTerms.length >= 2) confidence = "high";
  else if (score >= 45) confidence = "medium";

  return {
    score,
    bestExcerpt: bestExcerpt.excerpt,
    excerptScore: bestExcerpt.score,
    confidence,
  };
}

async function detectHealthInsurance(question: string) {
  const normalizedQuestion = normalizeQuery(question);

  const healthInsurances = await prisma.healthInsurance.findMany({
    where: {
      isActive: true,
    },
    select: {
      id: true,
      name: true,
      code: true,
    },
  });

  let bestMatch: {
    id: string;
    name: string;
    code: string | null;
    score: number;
  } | null = null;

  for (const item of healthInsurances) {
    const normalizedName = normalizeQuery(item.name);
    const normalizedCode = normalizeQuery(item.code ?? "");

    let score = 0;

    if (normalizedName && normalizedQuestion.includes(normalizedName)) {
      score += 70;
    }

    if (normalizedCode && normalizedQuestion.includes(normalizedCode)) {
      score += 80;
    }

    const nameWords = normalizedName.split(" ").filter(Boolean);

    for (const word of nameWords) {
      if (word.length >= 3 && normalizedQuestion.includes(word)) {
        score += 15;
      }
    }

    if (score > 0 && (!bestMatch || score > bestMatch.score)) {
      bestMatch = {
        id: item.id,
        name: item.name,
        code: item.code,
        score,
      };
    }
  }

  return bestMatch;
}

function buildAnswer(scoredChunks: ScoredChunk[], detectedHealthInsurance?: { name: string } | null) {
  const best = scoredChunks[0];

  if (!best) {
    const scope = detectedHealthInsurance ? ` para ${detectedHealthInsurance.name}` : "";

    return `No encontré información suficiente${scope} en las normativas cargadas. Probá reformular la consulta o verificá que la normativa correspondiente esté cargada y activa.`;
  }

  const sourceLine = `Fuente: ${best.document.title}${best.page?.pageNumber ? `, página ${best.page.pageNumber}` : ""}.`;
  const heading = `Según la normativa de ${best.healthInsurance.name}:`;

  const alternatives = scoredChunks
    .slice(1)
    .filter((chunk) => {
      const closeScore = chunk.score >= best.score * 0.72;
      const differentText = normalizeQuery(chunk.bestExcerpt) !== normalizeQuery(best.bestExcerpt);
      return closeScore && differentText;
    })
    .slice(0, 2);

  if (best.confidence === "low") {
    return `${heading}\n\nEncontré una coincidencia posible, pero no es concluyente. Revisá este fragmento:\n\n${best.bestExcerpt}\n\n${sourceLine}`;
  }

  if (alternatives.length === 0) {
    return `${heading}\n\n${best.bestExcerpt}\n\n${sourceLine}`;
  }

  const alternativeText = alternatives
    .map((item, index) => {
      const alternativeSource = `${item.document.title}${item.page?.pageNumber ? `, página ${item.page.pageNumber}` : ""}`;
      return `${index + 1}. ${item.bestExcerpt}\nFuente: ${alternativeSource}.`;
    })
    .join("\n\n");

  return `${heading}\n\n${best.bestExcerpt}\n\n${sourceLine}\n\nTambién encontré otras coincidencias posibles. Si no te referías a lo anterior, puede ser esto:\n\n${alternativeText}`;
}

export async function searchNormativeAction(
  question: string
): Promise<ChatSearchResponse> {
  const user = await requireUser();
  const cleanQuestion = question.trim();

  if (!cleanQuestion) {
    return {
      answer: "Escribí una consulta para buscar en las normativas cargadas.",
      sources: [],
    };
  }

  const detectedHealthInsurance = await detectHealthInsurance(cleanQuestion);
  const normalizedQuestion = normalizeQuery(cleanQuestion);
  const rawWordsWithoutHealthInsurance = removeHealthInsuranceTerms(
    getRawWords(cleanQuestion),
    detectedHealthInsurance
  );
  const questionTerms = expandTerms(rawWordsWithoutHealthInsurance);
  const exactQuestion = normalizeQuery(rawWordsWithoutHealthInsurance.join(" "));

  const query = await prisma.query.create({
    data: {
      originalText: cleanQuestion,
      normalizedText: normalizedQuestion,
      userId: user.id,
      branchId: user.branchId ?? null,
      detectedHealthInsuranceId: detectedHealthInsurance?.id ?? null,
    },
  });

  if (questionTerms.length === 0) {
    revalidatePath("/admin/dashboard");

    return {
      answer:
        "Necesito una consulta un poco más específica para buscar en las normativas. Por ejemplo: validez de receta, requisitos de autorización, cobertura, documentación solicitada, etc.",
      sources: [],
    };
  }

  const chunks = await prisma.documentChunk.findMany({
    where: {
      healthInsuranceId: detectedHealthInsurance?.id ?? undefined,
      document: {
        isActive: true,
      },
      healthInsurance: {
        isActive: true,
      },
    },
    select: {
      id: true,
      documentId: true,
      pageId: true,
      healthInsuranceId: true,
      content: true,
      normalizedContent: true,
      keywords: true,
      scoreBase: true,
      document: {
        select: {
          title: true,
        },
      },
      page: {
        select: {
          pageNumber: true,
        },
      },
      healthInsurance: {
        select: {
          name: true,
          code: true,
        },
      },
    },
    take: 2500,
  });

  const scoredChunks: ScoredChunk[] = chunks
    .map((chunk) => {
      const normalizedChunk: ChunkForSearch = {
        ...chunk,
        keywords: Array.isArray(chunk.keywords) ? chunk.keywords.map(String) : [],
      };

      const result = scoreChunk({
        chunk: normalizedChunk,
        questionTerms,
        exactQuestion,
        question: cleanQuestion,
      });

      return {
        ...normalizedChunk,
        ...result,
      };
    })
    .filter((chunk) => chunk.score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, 6);

  if (scoredChunks.length === 0) {
    revalidatePath("/admin/dashboard");

    const scope = detectedHealthInsurance ? ` para ${detectedHealthInsurance.name}` : "";

    return {
      answer: `No encontré información suficiente${scope} en las normativas cargadas. Probá reformular la consulta o verificá que la normativa correspondiente esté cargada y activa.`,
      sources: [],
    };
  }

  const sources: SearchSource[] = scoredChunks.slice(0, 4).map((chunk) => ({
    documentTitle: chunk.document.title,
    healthInsuranceName: chunk.healthInsurance.name,
    pageNumber: chunk.page?.pageNumber ?? null,
    excerpt: chunk.bestExcerpt,
    score: chunk.score,
  }));

  await prisma.queryResult.createMany({
    data: scoredChunks.slice(0, 6).map((chunk) => ({
      queryId: query.id,
      documentId: chunk.documentId,
      chunkId: chunk.id,
      score: chunk.score,
      excerpt: chunk.bestExcerpt,
    })),
  });

  await prisma.query.update({
    where: {
      id: query.id,
    },
    data: {
      resultFound: scoredChunks.length > 0,
      topScore: scoredChunks[0]?.score ?? 0,
    },
  });

  const answer = buildAnswer(scoredChunks, detectedHealthInsurance);

  revalidatePath("/admin/dashboard");

  return {
    answer,
    sources,
  };
}
